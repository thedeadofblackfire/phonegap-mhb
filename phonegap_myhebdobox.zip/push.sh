git add .
git add -u
git commit -m "`date`"
git push origin
