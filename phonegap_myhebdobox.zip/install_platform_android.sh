echo "----------------"
echo "removing android"
echo "----------------"
cordova platform rm android
echo "----------------"
echo "creating android"
echo "----------------"
cordova platform add android
echo "----------------"
cordova platform ls