echo "----------------"
echo "removing browser"
echo "----------------"
cordova platform rm browser
echo "----------------"
echo "creating browser"
echo "----------------"
cordova platform add browser
echo "----------------"
cordova platform ls